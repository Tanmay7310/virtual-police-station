$ErrorActionPreference = 'Stop'
$base = 'http://localhost:8080/api'

$citLogin = Invoke-RestMethod -Method Post -Uri "$base/auth/login" -ContentType 'application/json' -Body (@{email='smoke.citizen@test.com';password='Password@123'} | ConvertTo-Json)
$polLogin = Invoke-RestMethod -Method Post -Uri "$base/auth/login" -ContentType 'application/json' -Body (@{email='smoke.police@test.com';password='Password@123'} | ConvertTo-Json)
$admLogin = Invoke-RestMethod -Method Post -Uri "$base/auth/login" -ContentType 'application/json' -Body (@{email='smoke.admin@test.com';password='Password@123'} | ConvertTo-Json)

$otpGen = Invoke-RestMethod -Method Post -Uri "$base/auth/otp/generate" -ContentType 'application/json' -Body (@{aadhaarNumber='101010101010'} | ConvertTo-Json)
$otpVerify = Invoke-RestMethod -Method Post -Uri "$base/auth/otp/verify" -ContentType 'application/json' -Body (@{aadhaarNumber='101010101010';otp=$otpGen.debugOtp} | ConvertTo-Json)

$citHeaders = @{ Authorization = "Bearer $($citLogin.token)" }
$fir = Invoke-RestMethod -Method Post -Uri "$base/citizen/fir" -Headers $citHeaders -ContentType 'application/json' -Body (@{title='Fraud Wallet Incident';description='I faced fraud through a fake payment app cyber theft';documentPath='';aadhaarNumber='101010101010'} | ConvertTo-Json)
Invoke-RestMethod -Method Post -Uri "$base/citizen/fir/$($fir.id)/evidence" -Headers $citHeaders -ContentType 'application/json' -Body (@{fileName='proof.png';fileType='image/png';storagePath='uploads/proof.png'} | ConvertTo-Json) | Out-Null
$citFirs = Invoke-RestMethod -Method Get -Uri "$base/citizen/fir" -Headers $citHeaders
$timeline = Invoke-RestMethod -Method Get -Uri "$base/citizen/fir/$($fir.id)/timeline" -Headers $citHeaders

$polHeaders = @{ Authorization = "Bearer $($polLogin.token)" }
$allFirs = Invoke-RestMethod -Method Get -Uri "$base/police/fir" -Headers $polHeaders
$updated = Invoke-RestMethod -Method Patch -Uri "$base/police/fir/$($fir.id)" -Headers $polHeaders -ContentType 'application/json' -Body (@{status='UNDER_REVIEW';priority='HIGH';category='FRAUD'} | ConvertTo-Json)

$admHeaders = @{ Authorization = "Bearer $($admLogin.token)" }
$stats = Invoke-RestMethod -Method Get -Uri "$base/admin/stats" -Headers $admHeaders
$users = Invoke-RestMethod -Method Get -Uri "$base/admin/users" -Headers $admHeaders

[PSCustomObject]@{
  CitizenRole = $citLogin.role
  PoliceRole = $polLogin.role
  AdminRole = $admLogin.role
  OtpVerified = $otpVerify.verified
  FirId = $fir.id
  FirCategory = $fir.category
  DigitalSignaturePresent = [bool]$fir.digitalSignatureHash
  CitizenFirCount = $citFirs.Count
  TimelineEvents = $timeline.Count
  PoliceVisibleFirs = $allFirs.Count
  UpdatedStatus = $updated.status
  AdminUsersCount = $users.Count
  AdminFirsCount = $stats.firs
} | ConvertTo-Json -Depth 5
