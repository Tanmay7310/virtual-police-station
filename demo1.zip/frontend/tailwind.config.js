/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        policeBlue: '#1F3A93',
        policeGold: '#F4C430',
        bgSoft: '#F8F9FC',
        card: '#FFFFFF',
        ok: '#22C55E',
        warn: '#F59E0B',
        err: '#EF4444',
      },
      boxShadow: {
        panel: '0 10px 30px rgba(31,58,147,0.12)',
      },
      fontFamily: {
        heading: ['Poppins', 'sans-serif'],
        body: ['Source Sans 3', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
