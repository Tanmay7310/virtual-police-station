import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export function Layout({ children }) {
  const { user, logout } = useAuth()
  const location = useLocation()

  return (
    <div className="app-shell min-h-screen">
      <header className="border-b border-blue-100 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <Link to="/" className="font-heading text-xl font-semibold text-policeBlue">
            Virtual Police Station
          </Link>
          <div className="flex items-center gap-4 text-sm">
            {user ? (
              <>
                <span className="rounded-full bg-policeGold/20 px-3 py-1 font-semibold text-policeBlue">
                  {user.name} ({user.role})
                </span>
                <button
                  onClick={logout}
                  className="rounded-md bg-policeBlue px-3 py-2 font-semibold text-white hover:bg-blue-800"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link className={navLink(location.pathname === '/login')} to="/login">
                  Login
                </Link>
                <Link className={navLink(location.pathname === '/register')} to="/register">
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">{children}</main>
    </div>
  )
}

function navLink(active) {
  return `rounded-md px-3 py-2 font-semibold ${
    active ? 'bg-policeBlue text-white' : 'text-policeBlue hover:bg-blue-50'
  }`
}
