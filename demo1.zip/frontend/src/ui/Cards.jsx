export function StatCard({ title, value, tone = 'blue' }) {
  const tones = {
    blue: 'from-policeBlue to-blue-700 text-white',
    gold: 'from-policeGold to-amber-400 text-policeBlue',
    green: 'from-ok to-emerald-600 text-white',
  }

  return (
    <div className={`rounded-xl bg-gradient-to-r ${tones[tone]} p-4 shadow-panel`}>
      <p className="text-sm opacity-90">{title}</p>
      <p className="mt-1 text-2xl font-heading font-bold">{value}</p>
    </div>
  )
}

export function Panel({ title, children, action }) {
  return (
    <section className="rounded-xl bg-card p-5 shadow-panel">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-heading text-lg font-semibold text-policeBlue">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  )
}
