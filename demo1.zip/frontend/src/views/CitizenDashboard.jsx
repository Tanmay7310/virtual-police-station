import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { http } from '../api/http'
import { Panel, StatCard } from '../ui/Cards'

function HelpHint({ tip }) {
  return (
    <span
      className="inline-flex h-5 w-5 cursor-help items-center justify-center rounded-full border border-policeBlue text-xs font-bold text-policeBlue"
      title={tip}
      aria-label={tip}
    >
      ?
    </span>
  )
}

function FieldWithHelp({ tip, children }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1">{children}</div>
      <HelpHint tip={tip} />
    </div>
  )
}

export function CitizenDashboard() {
  const [firs, setFirs] = useState([])
  const [otpAadhaar, setOtpAadhaar] = useState('')
  const [otpCode, setOtpCode] = useState('')
  const [verifiedAadhaar, setVerifiedAadhaar] = useState('')
  const [firMessage, setFirMessage] = useState('')
  const [otpState, setOtpState] = useState({ generated: false, verified: false, debugOtp: '' })
  const { register, handleSubmit, reset, watch, setValue } = useForm()
  const { register: evidenceRegister, handleSubmit: handleEvidenceSubmit, reset: resetEvidence } = useForm()
  const firAadhaar = watch('aadhaarNumber')

  const load = async () => {
    const { data } = await http.get('/citizen/fir')
    setFirs(data)
  }

  useEffect(() => {
    load()
  }, [])

  const generateOtp = async (aadhaarNumber) => {
    if (!aadhaarNumber?.trim()) {
      setFirMessage('Please enter Aadhaar first to generate OTP.')
      return
    }
    const { data } = await http.post('/auth/otp/generate', { aadhaarNumber })
    setFirMessage('OTP generated. Enter OTP and click Verify OTP.')
    setOtpState({ generated: true, verified: false, debugOtp: data.debugOtp })
  }

  const verifyOtp = async (aadhaarNumber, otp) => {
    const { data } = await http.post('/auth/otp/verify', { aadhaarNumber, otp })
    if (data.verified) {
      setVerifiedAadhaar(aadhaarNumber)
      setValue('aadhaarNumber', aadhaarNumber)
      setFirMessage('OTP verified. You can now submit FIR.')
    } else {
      setFirMessage('OTP is not valid. Please try again.')
    }
    setOtpState((prev) => ({ ...prev, verified: data.verified }))
  }

  const submitFir = async (values) => {
    setFirMessage('')
    if (!otpState.verified) {
      setFirMessage('Please complete OTP verification before submitting FIR.')
      return
    }
    if (values.aadhaarNumber !== verifiedAadhaar) {
      setFirMessage('Aadhaar in FIR form must match verified Aadhaar.')
      return
    }

    try {
      await http.post('/citizen/fir', values)
      setFirMessage('FIR submitted successfully.')
      reset({ aadhaarNumber: verifiedAadhaar })
      await load()
    } catch (err) {
      const serverMessage = err?.response?.data?.error
      setFirMessage(serverMessage || 'Unable to submit FIR. Please check details and try again.')
    }
  }

  const uploadEvidence = async (values) => {
    await http.post(`/citizen/fir/${values.firId}/evidence`, {
      fileName: values.fileName,
      fileType: values.fileType,
      storagePath: values.storagePath,
    })
    resetEvidence()
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard title="Total FIRs" value={firs.length} tone="blue" />
        <StatCard title="Open Cases" value={firs.filter((f) => f.status !== 'RESOLVED').length} tone="gold" />
        <StatCard title="Resolved" value={firs.filter((f) => f.status === 'RESOLVED').length} tone="green" />
      </div>

      <Panel title="Aadhaar OTP Verification">
        <div className="grid gap-3 sm:grid-cols-3">
          <FieldWithHelp tip="Type your 12-digit Aadhaar number. Example: 123456789012">
            <input
              id="aadhaar"
              className="input"
              placeholder="12-digit Aadhaar"
              value={otpAadhaar}
              onChange={(e) => setOtpAadhaar(e.target.value)}
            />
          </FieldWithHelp>
          <button className="rounded-md bg-policeBlue px-3 py-2 font-semibold text-white" onClick={() => generateOtp(otpAadhaar)}>
            Generate OTP
          </button>
          <div className="rounded-md bg-blue-50 p-2 text-sm text-policeBlue">
            Demo OTP: <strong>{otpState.debugOtp || '---'}</strong>
          </div>
          <FieldWithHelp tip="Enter the 6-digit OTP you received after clicking Generate OTP.">
            <input
              id="otp"
              className="input"
              placeholder="Enter OTP"
              value={otpCode}
              onChange={(e) => setOtpCode(e.target.value)}
            />
          </FieldWithHelp>
          <button className="rounded-md bg-policeGold px-3 py-2 font-semibold text-policeBlue" onClick={() => verifyOtp(otpAadhaar, otpCode)}>
            Verify OTP
          </button>
          <div className={`rounded-md p-2 text-sm ${otpState.verified ? 'bg-green-100 text-ok' : 'bg-amber-100 text-warn'}`}>
            {otpState.verified ? 'Verified' : 'Pending'}
          </div>
        </div>
        {firMessage && (
          <p className={`mt-3 text-sm ${firMessage.includes('successfully') || firMessage.includes('verified') ? 'text-ok' : 'text-err'}`}>
            {firMessage}
          </p>
        )}
      </Panel>

      <Panel title="File New FIR">
        <form className="grid gap-3" onSubmit={handleSubmit(submitFir)}>
          <FieldWithHelp tip="Write a short heading for your complaint. Example: Phone stolen near market.">
            <input className="input" placeholder="Title" {...register('title')} />
          </FieldWithHelp>
          <FieldWithHelp tip="Describe what happened, where it happened, and at what time in simple words.">
            <textarea className="input min-h-28" placeholder="Complaint description" {...register('description')} />
          </FieldWithHelp>
          <FieldWithHelp tip="Optional: type full path of your complaint file for OCR. Example: D:/docs/complaint.txt">
            <input className="input" placeholder="Complaint document path (for OCR)" {...register('documentPath')} />
          </FieldWithHelp>
          <FieldWithHelp tip="Enter the same 12-digit Aadhaar used in OTP verification.">
            <input className="input" placeholder="Aadhaar number" {...register('aadhaarNumber')} />
          </FieldWithHelp>
          <button
            className="w-fit rounded-md bg-policeBlue px-4 py-2 font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-400"
            type="submit"
            disabled={!otpState.verified || !firAadhaar || firAadhaar !== verifiedAadhaar}
          >
            Submit FIR
          </button>
          {!otpState.verified || firAadhaar !== verifiedAadhaar ? (
            <p className="text-xs text-warn">
              Submit is enabled only after OTP verification and matching Aadhaar.
            </p>
          ) : null}
        </form>
      </Panel>

      <Panel title="Upload Evidence">
        <form className="grid gap-3 sm:grid-cols-2" onSubmit={handleEvidenceSubmit(uploadEvidence)}>
          <FieldWithHelp tip="Type the FIR number you already submitted. You can copy it from the table below.">
            <input className="input" placeholder="FIR ID" {...evidenceRegister('firId')} />
          </FieldWithHelp>
          <FieldWithHelp tip="Type your file name with extension. Example: proof.jpg or bill.pdf">
            <input className="input" placeholder="File name" {...evidenceRegister('fileName')} />
          </FieldWithHelp>
          <FieldWithHelp tip="Type the file type. Example: image/jpeg, image/png, application/pdf">
            <input className="input" placeholder="File type (pdf/image)" {...evidenceRegister('fileType')} />
          </FieldWithHelp>
          <FieldWithHelp tip="Type where the file is saved on your system. Example: D:/evidence/proof.jpg">
            <input className="input" placeholder="Storage path" {...evidenceRegister('storagePath')} />
          </FieldWithHelp>
          <button className="w-fit rounded-md bg-policeGold px-4 py-2 font-semibold text-policeBlue" type="submit">
            Upload
          </button>
        </form>
      </Panel>

      <Panel title="Track FIR Status">
        <div className="overflow-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-policeBlue">
              <tr>
                <th className="py-2">ID</th>
                <th>Title</th>
                <th>Category</th>
                <th>Status</th>
                <th>Priority</th>
              </tr>
            </thead>
            <tbody>
              {firs.map((fir) => (
                <tr key={fir.id} className="border-t border-slate-100">
                  <td className="py-2">{fir.id}</td>
                  <td>{fir.title}</td>
                  <td>{fir.category}</td>
                  <td>{fir.status}</td>
                  <td>{fir.priority}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  )
}
