import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useAuth } from '../context/AuthContext'

const schema = z.object({
  email: z.email('Valid email required'),
  password: z.string().min(6, 'Minimum 6 characters'),
})

export function LoginPage() {
  const { login } = useAuth()
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(schema) })

  const onSubmit = async (values) => {
    await login(values.email, values.password)
  }

  return (
    <div className="mx-auto mt-10 max-w-md rounded-xl bg-white p-6 shadow-panel">
      <h1 className="font-heading text-2xl font-semibold text-policeBlue">Citizen & Officer Login</h1>
      <form className="mt-5 space-y-4" onSubmit={handleSubmit(onSubmit)}>
        <Field label="Email" error={errors.email?.message}>
          <input className="input" placeholder="user@email.com" {...register('email')} />
        </Field>
        <Field label="Password" error={errors.password?.message}>
          <input className="input" type="password" {...register('password')} />
        </Field>
        <button disabled={isSubmitting} className="w-full rounded-md bg-policeBlue px-4 py-2 font-semibold text-white">
          Sign In
        </button>
      </form>
    </div>
  )
}

function Field({ label, error, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-semibold text-policeBlue">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-err">{error}</span>}
    </label>
  )
}
