import { useEffect, useState } from 'react'
import { http } from '../api/http'
import { Panel, StatCard } from '../ui/Cards'

export function AdminDashboard() {
  const [stats, setStats] = useState({ users: 0, officers: 0, firs: 0, activeCases: 0 })
  const [users, setUsers] = useState([])

  const load = async () => {
    const [statsRes, usersRes] = await Promise.all([http.get('/admin/stats'), http.get('/admin/users')])
    setStats(statsRes.data)
    setUsers(usersRes.data)
  }

  useEffect(() => {
    load()
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-4">
        <StatCard title="Users" value={stats.users} tone="blue" />
        <StatCard title="Officers" value={stats.officers} tone="gold" />
        <StatCard title="FIRs" value={stats.firs} tone="green" />
        <StatCard title="Active Cases" value={stats.activeCases} tone="blue" />
      </div>
      <Panel title="User Management Snapshot">
        <div className="overflow-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="text-policeBlue">
                <th className="py-2">Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Aadhaar</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t border-slate-100">
                  <td className="py-2">{u.fullName}</td>
                  <td>{u.email}</td>
                  <td>{u.role}</td>
                  <td>{u.aadhaarNumber}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  )
}
