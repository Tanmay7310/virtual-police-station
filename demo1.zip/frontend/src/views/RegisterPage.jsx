import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useAuth } from '../context/AuthContext'

const schema = z.object({
  fullName: z.string().min(3),
  email: z.email(),
  password: z.string().min(6),
  aadhaarNumber: z.string().regex(/^\d{12}$/),
  role: z.enum(['CITIZEN', 'POLICE', 'ADMIN']),
})

export function RegisterPage() {
  const { register: signUp } = useAuth()
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { role: 'CITIZEN' },
  })

  return (
    <div className="mx-auto mt-8 max-w-xl rounded-xl bg-white p-6 shadow-panel">
      <h1 className="font-heading text-2xl font-semibold text-policeBlue">Register User</h1>
      <form className="mt-5 grid gap-4 sm:grid-cols-2" onSubmit={handleSubmit(signUp)}>
        <Field label="Full Name" error={errors.fullName?.message}>
          <input className="input" {...register('fullName')} />
        </Field>
        <Field label="Email" error={errors.email?.message}>
          <input className="input" {...register('email')} />
        </Field>
        <Field label="Password" error={errors.password?.message}>
          <input className="input" type="password" {...register('password')} />
        </Field>
        <Field label="Aadhaar Number" error={errors.aadhaarNumber?.message}>
          <input className="input" {...register('aadhaarNumber')} />
        </Field>
        <Field label="Role" error={errors.role?.message}>
          <select className="input" {...register('role')}>
            <option value="CITIZEN">Citizen</option>
            <option value="POLICE">Police Officer</option>
            <option value="ADMIN">Administrator</option>
          </select>
        </Field>
        <div className="sm:col-span-2">
          <button disabled={isSubmitting} className="w-full rounded-md bg-policeGold px-4 py-2 font-semibold text-policeBlue">
            Create Account
          </button>
        </div>
      </form>
    </div>
  )
}

function Field({ label, error, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-semibold text-policeBlue">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-err">Invalid value</span>}
    </label>
  )
}
