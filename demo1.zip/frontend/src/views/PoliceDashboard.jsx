import { useEffect, useState } from 'react'
import { http } from '../api/http'
import { Panel, StatCard } from '../ui/Cards'

export function PoliceDashboard() {
  const [firs, setFirs] = useState([])

  const load = async () => {
    const { data } = await http.get('/police/fir')
    setFirs(data)
  }

  useEffect(() => {
    load()
  }, [])

  const updateStatus = async (id, status) => {
    await http.patch(`/police/fir/${id}`, { status })
    await load()
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard title="Assigned / Visible" value={firs.length} tone="blue" />
        <StatCard title="Under Review" value={firs.filter((f) => f.status === 'UNDER_REVIEW').length} tone="gold" />
        <StatCard title="Investigating" value={firs.filter((f) => f.status === 'INVESTIGATING').length} tone="green" />
      </div>
      <Panel title="Manage FIR Complaints">
        <div className="space-y-3">
          {firs.map((fir) => (
            <div key={fir.id} className="rounded-lg border border-slate-200 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-semibold text-policeBlue">#{fir.id} {fir.title}</h3>
                  <p className="text-sm text-slate-600">{fir.description}</p>
                  <p className="text-xs text-slate-500">Category: {fir.category} | Priority: {fir.priority}</p>
                </div>
                <div className="flex gap-2">
                  {['UNDER_REVIEW', 'INVESTIGATING', 'RESOLVED'].map((s) => (
                    <button
                      key={s}
                      onClick={() => updateStatus(fir.id, s)}
                      className="rounded-md border border-policeBlue px-2 py-1 text-xs font-semibold text-policeBlue"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  )
}
