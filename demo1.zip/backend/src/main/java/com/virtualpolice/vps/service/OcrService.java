package com.virtualpolice.vps.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class OcrService {
    private final String tesseractCommand;

    public OcrService(@Value("${app.ocr.tesseract-command}") String tesseractCommand) {
        this.tesseractCommand = tesseractCommand;
    }

    public String extractText(String documentPath) {
        if (documentPath == null || documentPath.isBlank()) {
            return "";
        }

        Path path = Path.of(documentPath);
        if (!Files.exists(path)) {
            return "";
        }

        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                    tesseractCommand,
                    path.toAbsolutePath().toString(),
                    "stdout"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            int exit = process.waitFor();
            if (exit == 0) {
                return output.toString().trim();
            }
        } catch (Exception ignored) {
        }

        try {
            return Files.readString(path);
        } catch (IOException e) {
            return "";
        }
    }
}
