package com.virtualpolice.vps.service;

import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CategorizationService {
    private static final Map<String, String> KEYWORDS = Map.of(
            "theft", "THEFT",
            "cyber", "CYBERCRIME",
            "assault", "ASSAULT",
            "fraud", "FRAUD"
    );

    public String categorize(String text) {
        String value = text == null ? "" : text.toLowerCase();
        for (Map.Entry<String, String> entry : KEYWORDS.entrySet()) {
            if (value.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return "GENERAL";
    }
}
