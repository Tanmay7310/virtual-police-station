package com.virtualpolice.vps.dto;

import com.virtualpolice.vps.model.FirStatus;
import com.virtualpolice.vps.model.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDateTime;
import java.util.List;

public class AuthDtos {
    public record RegisterRequest(
            @NotBlank String fullName,
            @Email String email,
            @NotBlank String password,
            @Pattern(regexp = "\\d{12}") String aadhaarNumber,
            Role role
    ) {
    }

    public record LoginRequest(@Email String email, @NotBlank String password) {
    }

    public record AuthResponse(String token, Role role, String name) {
    }

    public record OtpGenerateRequest(@Pattern(regexp = "\\d{12}") String aadhaarNumber) {
    }

    public record OtpGenerateResponse(String message, String debugOtp) {
    }

    public record OtpVerifyRequest(@Pattern(regexp = "\\d{12}") String aadhaarNumber, @Pattern(regexp = "\\d{6}") String otp) {
    }

    public record OtpVerifyResponse(boolean verified, String message) {
    }

    public record FirCreateRequest(
            @NotBlank String title,
            @NotBlank String description,
            String documentPath,
            String aadhaarNumber
    ) {
    }

    public record FirUpdateRequest(FirStatus status, String category, String priority, Long assignedOfficerId) {
    }

    public record EvidenceUploadRequest(String fileName, String fileType, String storagePath) {
    }

    public record FirResponse(
            Long id,
            String title,
            String description,
            String category,
            FirStatus status,
            String priority,
            String extractedText,
            String digitalSignatureHash,
            String citizenName,
            LocalDateTime createdAt,
            List<StatusLogResponse> logs
    ) {
    }

    public record StatusLogResponse(FirStatus status, String updatedBy, LocalDateTime updatedAt) {
    }

    public record DashboardStats(long users, long officers, long firs, long activeCases) {
    }
}
