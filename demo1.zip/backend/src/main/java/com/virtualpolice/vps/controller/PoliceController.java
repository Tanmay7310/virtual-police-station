package com.virtualpolice.vps.controller;

import com.virtualpolice.vps.dto.AuthDtos;
import com.virtualpolice.vps.service.FirService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/police")
public class PoliceController {
    private final FirService firService;

    public PoliceController(FirService firService) {
        this.firService = firService;
    }

    @GetMapping("/fir")
    public List<AuthDtos.FirResponse> allFirs() {
        return firService.getAllFirs();
    }

    @PatchMapping("/fir/{id}")
    public AuthDtos.FirResponse updateFir(@PathVariable Long id,
                                          Authentication auth,
                                          @Valid @RequestBody AuthDtos.FirUpdateRequest request) {
        return firService.updateFir(id, auth.getName(), request);
    }
}
