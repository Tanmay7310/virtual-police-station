package com.virtualpolice.vps.service;

import com.virtualpolice.vps.dto.AuthDtos;
import com.virtualpolice.vps.model.*;
import com.virtualpolice.vps.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.List;

@Service
public class FirService {
    private final FirReportRepository firReportRepository;
    private final UserRepository userRepository;
    private final PoliceOfficerRepository policeOfficerRepository;
    private final EvidenceRepository evidenceRepository;
    private final StatusLogRepository statusLogRepository;
    private final OtpService otpService;
    private final OcrService ocrService;
    private final CategorizationService categorizationService;

    public FirService(FirReportRepository firReportRepository,
                      UserRepository userRepository,
                      PoliceOfficerRepository policeOfficerRepository,
                      EvidenceRepository evidenceRepository,
                      StatusLogRepository statusLogRepository,
                      OtpService otpService,
                      OcrService ocrService,
                      CategorizationService categorizationService) {
        this.firReportRepository = firReportRepository;
        this.userRepository = userRepository;
        this.policeOfficerRepository = policeOfficerRepository;
        this.evidenceRepository = evidenceRepository;
        this.statusLogRepository = statusLogRepository;
        this.otpService = otpService;
        this.ocrService = ocrService;
        this.categorizationService = categorizationService;
    }

    @Transactional
    public AuthDtos.FirResponse createFir(String citizenEmail, AuthDtos.FirCreateRequest request) {
        UserAccount citizen = userRepository.findByEmail(citizenEmail)
                .orElseThrow(() -> new IllegalArgumentException("Citizen not found"));

        if (!otpService.isVerified(request.aadhaarNumber())) {
            throw new IllegalStateException("Aadhaar OTP not verified");
        }

        String ocrText = ocrService.extractText(request.documentPath());
        String combined = request.description() + " " + ocrText;
        String category = categorizationService.categorize(combined);

        FirReport fir = new FirReport();
        fir.setCitizen(citizen);
        fir.setTitle(request.title());
        fir.setDescription(request.description());
        fir.setExtractedText(ocrText);
        fir.setCategory(category);
        FirReport saved = firReportRepository.save(fir);

        saved.setDigitalSignatureHash(generateSignature(citizen.getAadhaarNumber(), saved.getId(), saved.getCreatedAt()));
        firReportRepository.save(saved);

        logStatus(saved, FirStatus.SUBMITTED, citizenEmail);
        return toResponse(saved);
    }

    public List<AuthDtos.FirResponse> getCitizenFirs(String email) {
        Long citizenId = userRepository.findByEmail(email).orElseThrow().getId();
        return firReportRepository.findByCitizenId(citizenId).stream().map(this::toResponse).toList();
    }

    public List<AuthDtos.FirResponse> getAllFirs() {
        return firReportRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Transactional
    public AuthDtos.FirResponse updateFir(Long id, String officerEmail, AuthDtos.FirUpdateRequest request) {
        FirReport fir = firReportRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("FIR not found"));

        if (request.category() != null) {
            fir.setCategory(request.category());
        }
        if (request.priority() != null) {
            fir.setPriority(request.priority());
        }
        if (request.assignedOfficerId() != null) {
            PoliceOfficer officer = policeOfficerRepository.findById(request.assignedOfficerId())
                    .orElseThrow(() -> new IllegalArgumentException("Officer not found"));
            fir.setAssignedOfficer(officer);
        }
        if (request.status() != null) {
            fir.setStatus(request.status());
            logStatus(fir, request.status(), officerEmail);
        }

        return toResponse(firReportRepository.save(fir));
    }

    @Transactional
    public void uploadEvidence(Long firId, AuthDtos.EvidenceUploadRequest req) {
        FirReport fir = firReportRepository.findById(firId).orElseThrow(() -> new IllegalArgumentException("FIR not found"));
        EvidenceFile evidence = new EvidenceFile();
        evidence.setFir(fir);
        evidence.setFileName(req.fileName());
        evidence.setFileType(req.fileType());
        evidence.setStoragePath(req.storagePath());
        evidenceRepository.save(evidence);
    }

    public List<AuthDtos.StatusLogResponse> getTimeline(Long firId) {
        return statusLogRepository.findByFirIdOrderByUpdatedAtAsc(firId)
                .stream()
                .map(log -> new AuthDtos.StatusLogResponse(log.getStatus(), log.getUpdatedBy(), log.getUpdatedAt()))
                .toList();
    }

    private void logStatus(FirReport fir, FirStatus status, String actor) {
        StatusLog log = new StatusLog();
        log.setFir(fir);
        log.setStatus(status);
        log.setUpdatedBy(actor);
        statusLogRepository.save(log);
    }

    private String generateSignature(String aadhaar, Long firId, LocalDateTime timestamp) {
        String input = aadhaar + firId + timestamp;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(input.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("Unable to generate signature", e);
        }
    }

    private AuthDtos.FirResponse toResponse(FirReport fir) {
        return new AuthDtos.FirResponse(
                fir.getId(),
                fir.getTitle(),
                fir.getDescription(),
                fir.getCategory(),
                fir.getStatus(),
                fir.getPriority(),
                fir.getExtractedText(),
                fir.getDigitalSignatureHash(),
                fir.getCitizen().getFullName(),
                fir.getCreatedAt(),
                getTimeline(fir.getId())
        );
    }
}
