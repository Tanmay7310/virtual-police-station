package com.virtualpolice.vps;

import com.virtualpolice.vps.service.OcrService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class OcrServiceTest {

    @Autowired
    private OcrService ocrService;

    @Test
    void shouldFallbackToPlainTextReadWhenTesseractNotAvailable() throws Exception {
        Path tmp = Files.createTempFile("ocr-test", ".txt");
        Files.writeString(tmp, "This is a fraud and cyber complaint.");

        String text = ocrService.extractText(tmp.toString());

        assertTrue(text.toLowerCase().contains("fraud"));
    }
}
